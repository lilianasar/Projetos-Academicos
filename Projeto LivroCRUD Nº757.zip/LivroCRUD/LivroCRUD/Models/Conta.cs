﻿namespace LivroCRUD.Models {
    public class Conta {
        public Guid UidConta { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public int NivelAcesso { get; set; }

        public Conta() {
            setGuest();
        }

        public void setGuest() {
            UidConta = Guid.Empty;
            Nome = "Convidado";
            Email = "--------";
            NivelAcesso = 0;
        }
    }
}
