﻿namespace LivroCRUD.Models {
    public class ContaAcesso {
        public string TxtEmail { get; set; }
        public string TxtSenha { get; set; }
    }
}
