﻿using System.Data.SqlClient;
using System.Data;

namespace LivroCRUD.Models.Helpers {
    public class ContaHelperCRUD : HelperBase {
        public string guidAdminFicticio = "99999999-9999-9999-9999-999999999999";

        public Conta Autenticar(string email, string senha) {
            Conta c = new Conta();  //AutoAnónimo
            //daqui para baixo é feito ao nivel da tabela
            if (email.Equals("admin@biblio.pt") && senha.Equals("1234")) {
                c.UidConta = Guid.Parse(guidAdminFicticio);
                c.Nome = "Administrador";
                c.Email = email;
                c.NivelAcesso = 1;
            }
            return c;
        }

        public Conta GetContaPorUid(Guid uid) {
            Conta c = new Conta();
            if (uid == Guid.Parse(guidAdminFicticio)) {
                c.UidConta = uid;
                c.Nome = "Administrador";
                c.Email = "admin@biblio.pt";
                c.NivelAcesso = 1;
            }
            return c;
        }
    }
}
