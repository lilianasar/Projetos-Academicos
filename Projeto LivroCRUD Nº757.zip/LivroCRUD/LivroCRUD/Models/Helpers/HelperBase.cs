﻿namespace LivroCRUD.Models.Helpers {
    public class HelperBase {
        protected readonly string ConetorHerdado = Program.Conetor;
    }
}
