﻿using System.Data.SqlClient;
using System.Data;

namespace LivroCRUD.Models.Helpers {
    public class LivroHelperCRUD : HelperBase {
        //Referência para o que é devolvido
        public List<Livro> list(int estadoAVer) {
            //Criar tabela de dados
            DataTable folha = new DataTable();
            //Criar lista de saída
            List<Livro> listaDeSaida = new List<Livro>();
            //Criar conexão com a base de dados
            //!!!É preciso intalar o nuget no projeto!!!
            SqlDataAdapter telefone = new SqlDataAdapter();
            SqlCommand comando = new SqlCommand();
            SqlConnection conexao = new SqlConnection(base.ConetorHerdado);
            //Configurar a ligação
            comando.CommandType = CommandType.Text;
            //Comando - Selecionar todos os dados da tabela Livro
            comando.CommandText = "SELECT * FROM livro WHERE (estado = @estado OR @estado = 2)";
            //Adiciona estadoAVer ao @estado
            comando.Parameters.AddWithValue("@estado", estadoAVer);
            //Objeto que faz a conexão
            comando.Connection = conexao;
            //Comando a ser executado na conexão
            telefone.SelectCommand = comando;
            telefone.Fill(folha);
            //Fechar a ligação
            conexao.Close();
            //Descartar
            conexao.Dispose();

            //Criar uma lista de objetos a partir da folha
            if (folha.Rows.Count > 0) {
                //Criar objeto que contém informações das linhas
                foreach (DataRow linha in folha.Rows) {
                    Livro liv = new Livro();
                    liv.Uid = "" + linha["uid"];
                    liv.Titulo = "" + linha["titulo"];
                    liv.Autor = "" + linha["autor"];
                    liv.Genero = "" + linha["genero"];
                    liv.Sinopse = "" + linha["sinopse"];
                    liv.Editora = "" + linha["editora"];
                    liv.Isbn = "" + linha["isbn"];
                    liv.DtPublicacao = Convert.ToDateTime(linha["dtPublicacao"]);
                    liv.Estado = Convert.ToInt32(linha["estado"]);
                    listaDeSaida.Add(liv);
                }
            }
            return listaDeSaida;
        }

        //Salvar a lista de objetos
        public void save(Livro liv) {
            //Criar registo se não existir na base de dados
            if (String.IsNullOrEmpty(liv.Uid)) {
                //Criar novo comando
                SqlCommand comando = new SqlCommand();
                SqlConnection conexao = new SqlConnection(base.ConetorHerdado);
                //Configurar a ligação
                comando.CommandType = CommandType.Text;
                comando.CommandText = "INSERT INTO livro " +
                    " (titulo, autor, genero, sinopse, editora, isbn, dtPublicacao, estado) " +
                    " VALUES (@titulo, @autor, @genero, @sinopse, @editora, @isbn, @dtPublicacao, @estado) ";
                comando.Parameters.AddWithValue("@titulo", liv.Titulo);
                comando.Parameters.AddWithValue("@autor", liv.Autor);
                comando.Parameters.AddWithValue("@genero", liv.Genero);
                comando.Parameters.AddWithValue("@sinopse", liv.Sinopse);
                comando.Parameters.AddWithValue("@editora", liv.Editora);
                comando.Parameters.AddWithValue("@isbn", liv.Isbn);
                comando.Parameters.AddWithValue("@dtPublicacao", liv.DtPublicacao);
                comando.Parameters.AddWithValue("@estado", liv.Estado);
                //Conectar à base de dados
                comando.Connection = conexao;
                conexao.Open();
                comando.ExecuteNonQuery();
                //Fechar a ligação
                conexao.Close();
                //Descartar
                conexao.Dispose();
            } else {
                //Editar registo caso já exista na base de dados
                SqlCommand comando = new SqlCommand();
                SqlConnection conexao = new SqlConnection(base.ConetorHerdado);
                //Configurar a ligação
                comando.CommandType = CommandType.Text;
                comando.CommandText = "UPDATE livro " +
                    " SET titulo = @titulo, autor = @autor, genero = @genero, sinopse = @sinopse, editora = @editora, isbn = @isbn, dtPublicacao = @dtPublicacao, estado = @estado" +
                    " WHERE uid = @uid";
                comando.Parameters.AddWithValue("@uid", liv.Uid);
                comando.Parameters.AddWithValue("@titulo", liv.Titulo);
                comando.Parameters.AddWithValue("@autor", liv.Autor);
                comando.Parameters.AddWithValue("@genero", liv.Genero);
                comando.Parameters.AddWithValue("@sinopse", liv.Sinopse);
                comando.Parameters.AddWithValue("@editora", liv.Editora);
                comando.Parameters.AddWithValue("@isbn", liv.Isbn);
                comando.Parameters.AddWithValue("@dtPublicacao", liv.DtPublicacao);
                comando.Parameters.AddWithValue("@estado", liv.Estado);
                //Conectar à base de dados
                comando.Connection = conexao;
                conexao.Open();
                comando.ExecuteNonQuery();
                //Fechar a ligação
                conexao.Close();
                //Descartar
                conexao.Dispose();
            }
        }
        public Livro get(string id) {
            //Criar tabela de dados
            DataTable folha = new DataTable();
            Livro objetoSaida = new Livro();
            //Criar conexão com a base de dados
            SqlDataAdapter telefone = new SqlDataAdapter();
            SqlCommand comando = new SqlCommand();
            SqlConnection conexao = new SqlConnection(base.ConetorHerdado);
            //Configurar a ligação
            comando.CommandType = CommandType.Text;
            //Comando - Selecionar todos os dados da tabela Livro
            comando.CommandText = "SELECT * FROM livro WHERE uid = @uid";
            //Adiciona id ao @uid
            comando.Parameters.AddWithValue("@uid", id);
            //Objeto que faz a conexão
            comando.Connection = conexao;
            //Comando a ser executado na conexão
            telefone.SelectCommand = comando;
            telefone.Fill(folha);
            //Fechar a ligação
            conexao.Close();
            //Descartar
            conexao.Dispose();
            //Criar um único objeto a partir de folha se existir
            if (folha.Rows.Count == 1) {
                //Criar objeto que contém informações das linhas
                DataRow linha = folha.Rows[0];
                objetoSaida.Uid = "" + linha["uid"];
                objetoSaida.Titulo = "" + linha["titulo"];
                objetoSaida.Autor = "" + linha["autor"];
                objetoSaida.Genero = "" + linha["genero"];
                objetoSaida.Sinopse = "" + linha["sinopse"];
                objetoSaida.Editora = "" + linha["editora"];
                objetoSaida.Isbn = "" + linha["isbn"];
                objetoSaida.DtPublicacao = Convert.ToDateTime(linha["dtPublicacao"]);
                objetoSaida.Estado = Convert.ToInt32(linha["estado"]);
            } else {
                objetoSaida = null;
            }
            return objetoSaida;

        }
    }
}
