﻿using System.Reflection.Metadata;

namespace LivroCRUD.Models {
    public class Configuracao {
        public string Conexao { get; set; }
        public string smtpIP { get; set; }
        public string usesTLS { get; set; }

    }
}
