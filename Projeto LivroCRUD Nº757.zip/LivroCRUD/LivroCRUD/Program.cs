using LivroCRUD.Models;
using Microsoft.Extensions.Configuration.EnvironmentVariables;

internal class Program {

    public static string Conetor = "";
    public static string ipSMTP = "";

    private static void Main(string[] args) {
        var builder = WebApplication.CreateBuilder(args);

        //Tempo de sess�o - minutos de inatividade
        builder.Services.AddSession(s => s.IdleTimeout = TimeSpan.FromMinutes(20));

        //Adicionar Mvc
        builder.Services.AddMvc();

        //Configura��o das vari�veis Conexao e ipSMTP
        var config = builder.Configuration.GetSection("Configuracao").Get<Configuracao>();
        Conetor = config.Conexao;
        ipSMTP = config.smtpIP;

        //Constru��o da aplica��o
        var app = builder.Build();

        //Para poder aceder aos ficheiros da app/layout
        app.UseStaticFiles();
        app.UseRouting();

        //Usar conex�o - Login
        app.UseSession();

        //Criar rota para quando o c�digo � corrido
        app.MapControllerRoute(
            name: "default",
            pattern: "{controller=Livro}/{action=Listar}/{id?}"
            );

        app.Run();
    }
}