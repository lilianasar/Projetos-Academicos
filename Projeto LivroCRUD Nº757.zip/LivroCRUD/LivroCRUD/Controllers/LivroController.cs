﻿using LivroCRUD.Models;
using LivroCRUD.Models.Helpers;
using Microsoft.AspNetCore.Mvc;

namespace LivroCRUD.Controllers {
    public class LivroController : Controller {
        private Conta _conta;

        //não coloquei Teste

        //Condições para a view Listar
        public IActionResult Listar(string id) {
            getConta();

            LivroHelperCRUD lhc = new LivroHelperCRUD();
            int estadoAVer = 0;
            switch (id) {
                case "":
                case "Ativos":
                    estadoAVer = 1;
                    break;
                case "Inativos":
                    estadoAVer = 0;
                    break;
                case "Todos":
                    estadoAVer = 2;
                    break;
                default:
                    estadoAVer = 1;
                    break;
            }

            List<Livro> infoPraView = lhc.list(estadoAVer);
            return View(infoPraView);
        }

        //CRIAR
        //Obter
        [HttpGet]
        public IActionResult Criar() {
            getConta();
            if (_conta.NivelAcesso == 0) return RedirectToAction("Listar", "Livro");
            return View();
        }


        //Submeter
        [HttpPost]
        public IActionResult Criar(Livro livSubmetido) {
            getConta();
            if (_conta.NivelAcesso == 0) return RedirectToAction("Listar", "Livro");

            LivroHelperCRUD lhc = new LivroHelperCRUD();
            lhc.save(livSubmetido);
            return RedirectToAction("Listar", "Livro");
        }


        //EDITAR
        [HttpGet]
        public IActionResult Editar(string id) { //não é arbitrário, tem a ver com o definido na rota
            getConta();
            if (_conta.NivelAcesso == 0) return RedirectToAction("Listar", "Livro");

            LivroHelperCRUD lhc = new LivroHelperCRUD();
            Livro livPesquisado = lhc.get(id);
            if (livPesquisado == null) {
                return RedirectToAction("Listar", "Livro");
            }
            return View(livPesquisado);
        }

        [HttpPost]
        public IActionResult Editar(Livro livAtualizar) {
            getConta();
            if (_conta.NivelAcesso == 0) return RedirectToAction("Listar", "Livro");

            LivroHelperCRUD lhc = new LivroHelperCRUD();
            lhc.save(livAtualizar);
            return RedirectToAction("Listar", "Livro");
        }

        private void getConta() {
            string uid = "";
            _conta = new Conta();
            //------------------
            try {
                //aqui vejo se já tirei bilhete
                uid = HttpContext.Session.GetString("IdSessao");
            } catch {

            }
            if (uid == null || uid == "") uid = Guid.Empty.ToString();
            ContaHelperCRUD chc = new ContaHelperCRUD();
            _conta = chc.GetContaPorUid(Guid.Parse(uid)); //converter para guid
            //aqui compro ou renovo o bilhete
            HttpContext.Session.SetString("IdSessao", uid);
            ViewBag.ContaAtiva = _conta; //objeto que tem um guest - convidado
        }
    }
}
