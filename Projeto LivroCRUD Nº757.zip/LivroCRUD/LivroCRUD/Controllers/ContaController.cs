﻿using LivroCRUD.Models;
using LivroCRUD.Models.Helpers;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;

namespace LivroCRUD.Controllers {
    public class ContaController : Controller {
        private Conta _conta;

        [HttpGet]
        public IActionResult LogIn() {
            getConta();

            return View();
            //ContaHelperCRUD chc = new ContaHelperCRUD();
            //Conta conta = chc.Autenticar("admin@net.pt", "1234");
            //HttpContext.Session.SetString("IdSessao", conta.UidConta.ToString());
            //return RedirectToAction("Listar", "Documento");
        }


        [HttpPost]
        public IActionResult LogIn(ContaAcesso ca) {
            getConta();
            ContaHelperCRUD chc = new ContaHelperCRUD();
            Conta conta = chc.Autenticar(ca.TxtEmail, ca.TxtSenha);
            HttpContext.Session.SetString("IdSessao", conta.UidConta.ToString());
            return RedirectToAction("Listar", "Livro");
        }

        public IActionResult LogOut() {
            Conta c = new Conta();
            HttpContext.Session.SetString("IdSessao", c.UidConta.ToString());
            return RedirectToAction("Listar", "Livro");
        }

        private void getConta() {
            string uid = "";
            _conta = new Conta();
            //---------
            try {
                //aqui vejo se já tirei bilhete..
                uid = HttpContext.Session.GetString("IdSessao");
            } catch { }
            if (uid == null || uid == "") uid = Guid.Empty.ToString();
            ContaHelperCRUD chc = new ContaHelperCRUD();
            _conta = chc.GetContaPorUid(Guid.Parse(uid));
            //Aqui compro OU renovo o bilheto.
            HttpContext.Session.SetString("IdSessao", uid);
            ViewBag.ContaAtiva = _conta;
        }
    }
}
